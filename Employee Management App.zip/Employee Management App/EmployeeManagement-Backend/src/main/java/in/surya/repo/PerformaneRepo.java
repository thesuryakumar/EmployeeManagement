package in.surya.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.surya.entity.PerformanceReview;

public interface PerformaneRepo extends JpaRepository<PerformanceReview, Integer>{

}
